<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="css/navbar.css">
<title>Welcome</title>
</head>

<body>

<?php
	include_once("user_includes/accountInfo.php");
?>
<h2>Welcome</h2>
<p>This page will have useful content soon but for now, just stick with the navbar above</p>
</body>
</html>
