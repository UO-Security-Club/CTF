gcc -m32 -mpreferred-stack-boundary=2 -z execstack exploit_me.c -o exploit_me -fno-stack-protector
