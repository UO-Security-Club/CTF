gcc -m32 -mpreferred-stack-boundary=2 -z execstack update_info.c -o update_info -fno-stack-protector
