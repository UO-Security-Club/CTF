#setarch `uname -m` -R /bin/bash
#must be run first in order to spwn a new shell with ASLR disabled. This will follow for all child procs as well
#shell can be exited once challenge proc is detached from shell. ASLR will still be disabled for it.

echo "nohup socat tcp-listen:4001,fork,reuseaddr EXEC:/home/ctf-user/sandbox/arg_handler.sh,chroot=/home/ctf-user/sandbox &" | setarch `uname -m` -R /bin/bash
#socat tcp-listen:4001,fork,reuseaddr EXEC:/home/ubuntu/CTF_Challenges/network/challenge1/test_env/product_des_test/arg_handler.sh
