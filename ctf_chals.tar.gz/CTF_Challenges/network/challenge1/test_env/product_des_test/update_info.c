#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_ID_LEN 40
#define MAX_DESC_LEN 500

void barf(char *message, void *extra){
	printf(message, extra);
	exit(1);
}

void update_product_description(char *id, char *desc){
	char product_code[5], description[MAX_DESC_LEN];

	printf("[DEBUG]: description is at %p\n", description);

	strncpy(description, desc, MAX_DESC_LEN);
	strcpy(product_code, id);

	printf("Updating product #%s with description \'%s\'\n", product_code, desc);
}

int main(int argc, char *argv[], char *envp[])
{
	int i;
	char *id, *desc;

	if(argc < 2){
		barf("Usage: %s <id> <description>\n", argv[0]);
	}

	id = argv[1];
	desc = argv[2];

	if(strlen(id) > MAX_ID_LEN) // MAX_ID_LEN = 40
		barf("Fatal: id argument must be less than %u bytes\n", (void*)MAX_ID_LEN);

	for(i=0; i<strlen(desc)-1; i++){
		if(!(isprint(desc[i]))){
			barf("Fatal: description argument can only contain printable bytes\n", NULL);
		}
	}

	//Clearing out stack memory for security reasons. We're so hardcore smart UGUYYYZZZ
	//Also clearing out args except for 1st and 2nd
	memset(argv[0], 0, strlen(argv[0]));

	for(i=3; argv[i] != 0; i++)
		memset(argv[i], 0, strlen(argv[i]));

	//Clearing out env vars
	for(i=0; envp[i] != 0; i++)
		memset(envp[i], 0, strlen(envp[i]));

	printf("[DEBUG]: desc is at %p\n", desc);
	update_product_description(id, desc);

	return(0);
}










