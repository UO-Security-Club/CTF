#!/bin/bash

echo "Enter product ID:"
read arg1
echo "Enter Product Description:"
read arg2

./update_info $arg1 $arg2
