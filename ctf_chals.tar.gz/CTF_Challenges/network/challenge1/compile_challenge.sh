gcc -m32 -mpreferred-stack-boundary=2 exploit_me.c -o exploit_me -fno-stack-protector
