#!/bin/sh
#nohup socat tcp-listen:7776,fork,reuseaddr EXEC:/home/ubuntu/test.sh &

nohup python bhpnet.py -p 7777 -l -e="True" &
