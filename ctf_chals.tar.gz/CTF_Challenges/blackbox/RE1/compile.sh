gcc -m32 -mpreferred-stack-boundary=2 re.c -o re1
