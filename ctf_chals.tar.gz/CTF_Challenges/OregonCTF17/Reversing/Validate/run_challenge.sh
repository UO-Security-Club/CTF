#!/bin/sh

nohup socat tcp-listen:21220,fork,reuseaddr EXEC:/home/ubuntu/CTF_Challenges/OregonCTF17/Reversing/Validate/validate &
