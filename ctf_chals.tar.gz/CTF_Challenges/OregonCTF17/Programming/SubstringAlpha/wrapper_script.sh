python substringAlpha.py
