#!/bin/sh

nohup socat tcp-listen:2211,fork,reuseaddr EXEC:/home/ubuntu/CTF_Challenges/OregonCTF17/Programming/SubstringAlpha/wrapper_script.sh &
