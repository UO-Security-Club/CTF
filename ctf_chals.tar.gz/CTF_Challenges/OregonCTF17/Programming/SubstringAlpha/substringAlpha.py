import random
import sys

class sentence_Gen:

	def __init__(self):
		self.sentenceFD = open("sentenceList.txt")
		self.sentenceList=[]
		random.seed(None)	

	def read_sentence_File(self):
		if not self.sentenceFD:
			print "Error: Failed to open sentence list file"
			exit(1)

		for line in self.sentenceFD:
			self.sentenceList.append(line)

		#print self.sentenceList

	def choose_sentence(self):
		expected_response = ""
		first_or_last = random.randint(0, 1)
		upper_range = len(self.sentenceList)-1
		s_index = random.randint(0, upper_range)
		#print "Chose Sentence: " + self.sentenceList[s_index]

		sentence_choice = self.sentenceList[s_index]
		word_list=[]
		word_list = sentence_choice.split()
		word_count = random.randint(1, len(word_list))

		if first_or_last == 0:
			for i in range(0, word_count):
				if i > 0 and i < word_count:
					expected_response += " "
				expected_response += word_list[i]
			print "Return the first %d words: %s" % (word_count, sentence_choice)
			#print "[DEBUG] Expected Response: %s" % (expected_response)
		else:
			for i in range(len(word_list) - word_count, len(word_list)):
				if i > (len(word_list) - word_count) and i < len(word_list):
					expected_response += " "
				expected_response += word_list[i]
			print "Return the last %d words: %s" % (word_count, sentence_choice)
			#print "[DEBUG] Expected Response: %s" % (expected_response)

		sys.stdout.flush()	
		usr_response = raw_input()
		#print usr_response

		if usr_response == expected_response:
			return 1
		else:
			return 0
		#print "Expected Response: %s" % (self.expected_response)

score = 0
SG = sentence_Gen()
SG.read_sentence_File()

while(score < 100):
	ret = SG.choose_sentence()
	if ret != 1:
		print "WRONG"
		exit(1)
	else:
		score += 1

print "Congrats! Here's your flag: "


